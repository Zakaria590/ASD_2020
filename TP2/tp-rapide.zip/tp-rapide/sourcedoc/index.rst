---------
Quicksort
---------

.. toctree::
   :maxdepth: 1

   modules.rst

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Décrivez ici l'état d'avancement du TP.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

------------------------------
2.2. Rappels sur le tri rapide
-------------------------------

Question 2.2.1
--------------

D'autres tris sur place seraient par exemple le tri fusion ou le tri par insertion
lorsqu'on echange deux valeurs.

Question 2.2.2
--------------
Pour partitionner un tableau sans avoir à utiliser de l'espace mémoire supplémentaire
, il faut faire des échanges d'éléments.

Question 2.2.3
--------------
On peut vérifier que chacun des éléments à gauche du pivot sont bien inférieurs au pivot.

Question 2.2.8
--------------
En prenant chaque initialisation de variable, pour la partition on a 5 unités de mémoires.
On utilise donc 5 unités de mémoire pour le tri rapide.

-----------------------
2.3. Sélection du pivot
-----------------------

Question 2.3.1.5
----------------

Question 2.3.2.1
----------------

Théoriquement, la meilleure valeur pour le pivot c'est la valeur au milieu.
