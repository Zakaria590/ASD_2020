#ifndef ARBREBINAIRE
#include "ArbreBinaire.h"
#endif

void SauverArbreDansFichier (Noeud_t ,char *) ; 
