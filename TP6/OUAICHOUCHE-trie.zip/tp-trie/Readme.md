-----------------
tp-trie
-----------------
Salah Zakaria OUAICHOUCHE  Groupe3 
~~~~~~~~~~
Etat du TP
~~~~~~~~~~

TP Fini.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~
J'ai repondu au questions demandé et en plus j'ai fait un test unitaire et la je vous explique comment l'executer manuellemet ou en utilassant le makefile directement.


# Pour compiler le test:

## Ce positionner à la racine (src-java)
```
javac -classpath test-1.7.jar test/TrieTest.java
```
# Pour cexecuter le test:

## Ce positionner à la racine (src-java)
```
	java -jar test-1.7.jar TrieTest
```
ou

## ce placer a la racine (src-java)
* make TrieTest


# Pour utiliser le makefile :

## Ce positionner à la racine (src-java)
## Pour compiler :
* make  ou make TrieMain

## Pour cree l1 figure1
## Ce positionner à la racine (src-java)
* make figures1

## Pour cree la figure2
## Ce positionner à la racine (src-java)
* make figures2







